package com.cg.sample;

public interface IExchangeService {
	public double getExchangeRate();

}
