package com.cg.sample;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.support.ClassPathXmlApplicationContext;


@ComponentScan("com.cg.sample")
@EnableAutoConfiguration
@PropertySource("classpath:/user.properties")
public class UserClient {
	public static void main(String[] args) 
	{
		ApplicationContext clx=SpringApplication.run(UserClient.class, args);
		User user=(User)clx.getBean("user");
		System.out.println(user.getUserName());
		System.out.println(user.getPassword());
		
	}


}
