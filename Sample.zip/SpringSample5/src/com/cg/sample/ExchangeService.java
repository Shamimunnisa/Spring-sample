package com.cg.sample;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.stereotype.Component;

@Component("exchangeService")
public class ExchangeService implements IExchangeService
{
	@Value("44.25")
private double exchangeRate;

	
	


	/*@Override
	public double getExchangeRate() {
		// TODO Auto-generated method stub
		return 0;
	}*/

	//default constructor
public ExchangeService() {
		super();
		// TODO Auto-generated constructor stub
	}

public double getExchangeRate() {
	return exchangeRate;
}

/*public void setExchangeRate(double exchangeRate) {
	this.exchangeRate = exchangeRate;
}
*/




	//constructor
	public ExchangeService(double exchangeRate) {
		super();
		this.exchangeRate = exchangeRate;
	}

	
}
