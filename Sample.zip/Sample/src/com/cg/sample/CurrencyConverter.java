package com.cg.sample;

public class CurrencyConverter implements ICurrencyConverter
{
	//private double exchangeRate;
	private ExchangeService exchangeService;
	
	
	//getter and setter

	public ExchangeService getExchangeService() {
		return exchangeService;
	}


	public void setExchangeService(ExchangeService exchangeService) {
		this.exchangeService = exchangeService;
	}


	@Override
	public double dollartoRupees(double dollars)
	{
		double conv=dollars*exchangeService.getExchangeRate();
		
		return conv;
	}
	
	
	
	
	
	
	
	
	
	
	
	
	/*//constructor

	public CurrencyConverter(double exchangeRate) {
		super();
		this.exchangeRate = exchangeRate;
	}
*/



	/*//getters and setters
	public double getExchangeRate() {
		return exchangeRate;
	}

	public void setExchangeRate(double exchangeRate) {
		this.exchangeRate = exchangeRate;
	}*/

	
}
