package com.cg.sample;

public class ExchangeService implements IExchangeService
{
private double exchangeRate;

	
	


	/*@Override
	public double getExchangeRate() {
		// TODO Auto-generated method stub
		return 0;
	}*/

public double getExchangeRate() {
	return exchangeRate;
}

public void setExchangeRate(double exchangeRate) {
	this.exchangeRate = exchangeRate;
}





	//constructor
	public ExchangeService(double exchangeRate) {
		super();
		this.exchangeRate = exchangeRate;
	}

	
}
