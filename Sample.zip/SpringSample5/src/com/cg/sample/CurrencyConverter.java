package com.cg.sample;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component("currencyConverter")
public class CurrencyConverter implements ICurrencyConverter
{
	//private double exchangeRate;
	@Autowired
	private ExchangeService exchangeService;
	
	
	@Autowired
	public CurrencyConverter(ExchangeService exchangeService) {
		super();
		this.exchangeService = exchangeService;
	}


	//getter and setter

	public ExchangeService getExchangeService() {
		return exchangeService;
	}


	public void setExchangeService(ExchangeService exchangeService) {
		this.exchangeService = exchangeService;
	}


	@Override
	public double dollartoRupees(double dollars)
	{
		double conv=dollars*exchangeService.getExchangeRate();
		
		return conv;
	}
	
	
	public CurrencyConverter() {
		super();
		// TODO Auto-generated constructor stub
	}


	@PostConstruct
	public void init()
	{
		System.out.println("init method");
	}
	
	@PreDestroy
	public void destroy()
	{
		System.out.println("destroy method");
	}
	
	
	
	
	
	
	
	
	
	
	
}
