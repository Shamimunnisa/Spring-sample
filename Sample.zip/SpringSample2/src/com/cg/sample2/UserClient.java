package com.cg.sample2;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class UserClient 
{
	public static void main(String[] args) 
	{
		ApplicationContext clx= new ClassPathXmlApplicationContext("user.xml");
		User user=(User)clx.getBean("user");
		System.out.println(user.getUsername());
		System.out.println(user.getPassword());
		
	}

}
