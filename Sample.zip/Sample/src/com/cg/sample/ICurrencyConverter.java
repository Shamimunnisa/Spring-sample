package com.cg.sample;

public interface ICurrencyConverter {
	
	public double dollartoRupees(double dollars);

}
